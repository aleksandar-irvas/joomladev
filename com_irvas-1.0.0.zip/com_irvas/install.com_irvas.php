<?php 
defined('_JEXEC') or die;

/*function com_install(){
   global $database;

   //get database

    $database = JFactory::getDBO();
 
   
   //table for item index
   $database->setQuery("CREATE TABLE IF NOT EXISTS `#__irvas_contacts` (
   `id` int(10) unsigned NOT NULL AUTO_INCREMENT, 
   `title` varchar(250) NOT NULL DEFAULT '', 
   `name` varchar(255) NOT NULL DEFAULT '', 
   PRIMARY KEY (`id`)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
    $database->query();

}*/
?>